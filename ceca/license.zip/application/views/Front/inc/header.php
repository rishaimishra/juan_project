<html>
<head>
<title><?= $title; ?></title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<!-- jQuery -->
        <script src="<?php echo base_url();?>adminassets/js/jquery-3.2.1.min.js"></script>
        <script src="<?php echo base_url();?>adminassets/js/bootstrap.min.js"></script>

</head>
<body>

	<div class="header">
		<center>
		  <a href="https://www.bidinline.com" class="logo">
		  	<img src="https://www.bidinline.com/images/logo.png" class="logo">
		  </a>
		</center>
	</div>



<style>

label{
	margin-top: 10px
}
.mt-50{
	margin-top: 30px
}
	.logo{
		    height: 110px;
	}
	.panel-default>.panel-heading {
    color: #fff;
    background-color: #0e73b3;
    border-color: #ddd;
    text-align: center;
    font-size: 21px;
    padding: 15px;
    text-transform: capitalize;
}


.header {
    overflow: hidden;
    background-color: #ffffff;
    padding: 0px 10px;
    box-shadow: 0px 4px 44px 0px rgb(0 0 0 / 14%);
}



.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

</style>