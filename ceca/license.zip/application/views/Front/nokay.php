

<div class="container" style="padding-top: 50px">
	<div class="row">
		<div class="col-md-12">
			<center>
				<h1 style="color: red"><u>ERROR!</u></h1>
			</center>
			<center><p style="font-size: 20px;">Something went wrong, Please try again later.</p></center>
			<br>
			<center><a href="https://www.bidinline.com/ventas/facturas/"><button class="btn btn-success">Back to Home</button></a></center>
		</div>
	</div>
</div>

<script>
$(document).ready(function () {
window.history.forward(1);
});
   </script>